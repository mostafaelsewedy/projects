
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Vector;

/**
 * @author mohamed
 */
class BTreeLeafNode<TKey extends Comparable<TKey>, TValue> extends BTreeNode<TKey> implements Serializable{
	protected final static int LEAFORDER = 4;
	/**
	 * @uml.property name="values"
	 */
	private final Vector<TablePointer>[] values;
	/**
	 * @uml.property name="filters"
	 * @uml.associationEnd multiplicity="(0 -1)" elementType="java.lang.Boolean"
	 */
	private ArrayList<Boolean> filters;

	public BTreeLeafNode() {
		this.filters = new ArrayList<>();
		this.keys = new Object[LEAFORDER + 1];
		this.values = new Vector[LEAFORDER + 1];
		for(int i = 0 ;i<values.length ;i++) {
			values[i] = new Vector<TablePointer>();
		}
	}

	public BTreeLeafNode(BTreeLeafNode smallest) {
		this.keys = smallest.keys;
		this.values = smallest.values;
	}

	@SuppressWarnings("unchecked")
	public Vector<TablePointer> getValue(int index) {
		return (Vector<TablePointer>) this.values[index];
	}

	public void setValue(int index, Vector<TablePointer> value) {
//		this.values[index]= value;
		 this.values[index] = value;
	}

	@Override
	public TreeNodeType getNodeType() {
		return TreeNodeType.LeafNode;
	}

	@Override
	public int search(TKey key) {
		for (int i = 0; i < this.getKeyCount(); ++i) {
			int cmp = this.getKey(i).compareTo(key);
			if (cmp == 0) {
				return i;
			} else if (cmp > 0) {
				return -1;
			}
		}

		return -1;
	}
	
	public Vector<TablePointer> searchForInsert(TKey key) {
		int i;
		for ( i = 0; i < this.getKeyCount(); ++i) {
			int cmp = this.getKey(i).compareTo(key);
			if (cmp == 0) {
				return null;
			} else if (cmp > 0) {
				return this.getValue(i);
			}
		}
		
		BTreeLeafNode rightSibling = (BTreeLeafNode)this.MyGetRightSibling();
		if(rightSibling == null) {
			return this.getValue(i -1);
		}
		System.out.println("sibling not null");
		return checkRightSibling(rightSibling , key);
	}
	
	public Vector<TablePointer> searchForGreater(TKey key,Vector<TablePointer> pointers) {
		int i;
		for ( i = 0; i < this.getKeyCount(); ++i) {
			int cmp = this.getKey(i).compareTo(key);
			if (cmp == 0) {
			} else if (cmp > 0) {
				for(TablePointer pointer : this.getValue(i)) {
					pointers.add(pointer);
				}
			}
		}
		
		BTreeLeafNode rightSibling = (BTreeLeafNode)this.MyGetRightSibling();
		if(rightSibling == null) {
			return pointers;
			//pointers.add(this.getValue(i));
		}
		return rightSibling.searchForGreater(key , pointers);
	}
	
	
	
	public Vector<TablePointer> searchForGreaterEqual(TKey key,Vector<TablePointer> pointers) {
		int i;
		for ( i = 0; i < this.getKeyCount(); ++i) {
			int cmp = this.getKey(i).compareTo(key);
			if (cmp == 0) {
				for(TablePointer pointer : this.getValue(i)) {
					pointers.add(pointer);
				}
			} else if (cmp > 0) {
				for(TablePointer pointer : this.getValue(i)) {
					pointers.add(pointer);
				}
			}
		}
		
		BTreeLeafNode rightSibling = (BTreeLeafNode)this.MyGetRightSibling();
		if(rightSibling == null) {
			return pointers;
			//pointers.add(this.getValue(i));
		}
		return rightSibling.searchForGreaterEqual(key , pointers);
	}
	
	public Vector<TablePointer> searchForSmaller(TKey key,Vector<TablePointer> pointers) {
		int i;
		for ( i = this.getKeyCount() -1; i>=0; --i) {
			int cmp = this.getKey(i).compareTo(key);
			if (cmp < 0) {
				for(TablePointer pointer : this.getValue(i)) {
					pointers.add(pointer);
				}
			}
		}
		
		BTreeLeafNode leftSibling = (BTreeLeafNode)this.MygetLeftSibling();
		if (leftSibling != null) {
	        // Recursively call searchForGreater on the right sibling
	        return leftSibling.searchForSmaller(key, pointers);
	    }
	    
	    return pointers;
	}
	
	public Vector<TablePointer> searchForSmallerEqual(TKey key,Vector<TablePointer> pointers) {
		int i;
		for ( i = this.getKeyCount() -1; i>=0; --i) {
			int cmp = this.getKey(i).compareTo(key);
			if (cmp == 0) {
				for(TablePointer pointer : this.getValue(i)) {
					pointers.add(pointer);
				}
			}
			if (cmp < 0) {
				for(TablePointer pointer : this.getValue(i)) {
					pointers.add(pointer);
				}
			}
		}
		
		BTreeLeafNode leftSibling = (BTreeLeafNode)this.MygetLeftSibling();
		if (leftSibling != null) {
	        // Recursively call searchForGreater on the right sibling
	        return leftSibling.searchForSmallerEqual(key, pointers);
	    }
	    
	    return pointers;
	}
	
	public Vector<TablePointer> searchEqual(TKey key,Vector<TablePointer> pointers) {
		int i;
		for ( i = 0; i < this.getKeyCount(); ++i) {
			int cmp = this.getKey(i).compareTo(key);
			if (cmp == 0) {
				for(TablePointer pointer : this.getValue(i)) {
					pointers.add(pointer);
				}
				return pointers;
			} 
		}
		
		BTreeLeafNode thisRightSibling = (BTreeLeafNode)this.getRightSibling();
		System.out.println("right sibling is " + thisRightSibling);
		if (thisRightSibling != null) {
	        // Recursively call searchForGreater on the right sibling
	        return thisRightSibling.searchForGreater(key, pointers);
	    }
	    
	    return pointers;
	}
	
	public Vector<TablePointer> searchNotEqual(TKey key,Vector<TablePointer> pointers) {
		pointers = searchForSmaller(key,pointers);
		pointers = searchForGreater (key,pointers);
		return pointers;
	}
	
	
	
	public Vector<TablePointer> checkRightSibling(BTreeLeafNode rightSibling ,TKey key) {
		int i;
		for ( i = 0; i < rightSibling.getKeyCount(); ++i) {
			int cmp = rightSibling.getKey(i).compareTo(key);
			if (cmp == 0) {
				return null;
			} else if (cmp > 0) {
				return rightSibling.getValue(i);
			}
		}
		
		BTreeLeafNode nextRightSibling = (BTreeLeafNode)rightSibling.getRightSibling();
		
		if(nextRightSibling == null) {
			return rightSibling.getValue(i -1);
		}
		return checkRightSibling(nextRightSibling , key);
	}
	
//	public Vector<TablePointer> checkLeftSibling(BTreeLeafNode leftSibling ,TKey key) {
//		int i;
//		for ( i = 0; i < rightSibling.getKeyCount(); ++i) {
//			int cmp = rightSibling.getKey(i).compareTo(key);
//			if (cmp == 0) {
//				return null;
//			} else if (cmp > 0) {
//				return rightSibling.getValue(i);
//			}
//		}
//		
//		BTreeLeafNode nextRightSibling = (BTreeLeafNode)rightSibling.getRightSibling();
//		
//		if(nextRightSibling == null) {
//			return rightSibling.getValue(i -1);
//		}
//		return checkRightSibling(nextRightSibling , key);
//	}

	@Override
	public String toString() {
		String out = "";
		for (int index = 0; index < this.getKeyCount(); ++index) {
			out += this.getKey(index).toString() + " ";
		}
		return out;
	}

	/* The codes below are used to support insertion operation */

	public void insertKey(TKey key, Vector<TablePointer> value) {
		int index = 0;
		while (index < this.getKeyCount() && this.getKey(index).compareTo(key) < 0) {
			++index;
		}
		
		if(index < this.getKeyCount() && this.getKey(index).compareTo(key) == 0) {
			this.setKey(index, key);
			Vector<TablePointer> newValue = this.getValue(index);
			newValue.add(value.get(0));
			this.setValue(index, newValue);
			return;
		}
		
		Vector<TablePointer> newValue = new Vector<TablePointer>();
		newValue.add(value.get(0));
		this.insertAt(index, key, newValue);
	}

	private void insertAt(int index, TKey key, Vector<TablePointer> value) {
		// move space for the new key
		for (int i = this.getKeyCount() - 1; i >= index; --i) {
			this.setKey(i + 1, this.getKey(i));
			this.setValue(i + 1, this.getValue(i));
		}

		// insert new key and value
		this.setKey(index, key);
		this.setValue(index, value);
		++this.keyCount;
	}

	/**
	 * When splits a leaf node, the middle key is kept on new node and be pushed
	 * to parent node.
	 */
	@Override
	protected BTreeNode<TKey> split() {
		int midIndex = this.getKeyCount() / 2;

		BTreeLeafNode<TKey, TValue> newRNode = new BTreeLeafNode<TKey, TValue>();
		for (int i = midIndex; i < this.getKeyCount(); ++i) {
			newRNode.setKey(i - midIndex, this.getKey(i));
			newRNode.setValue(i - midIndex, this.getValue(i));
			this.setKey(i, null);
			this.setValue(i, null);
		}
		newRNode.keyCount = this.getKeyCount() - midIndex;
		this.keyCount = midIndex;

		return newRNode;
	}

	@Override
	protected BTreeNode<TKey> pushUpKey(TKey key, BTreeNode<TKey> leftChild, BTreeNode<TKey> rightNode) {
		throw new UnsupportedOperationException();
	}

	/* The codes below are used to support deletion operation */

	public boolean delete(TKey key,TablePointer value) {
		int index = this.search(key);
		if (index == -1)
			return false;
		
		if(this.values[index].size()>1) {
			this.values[index].remove(value);
			return false;
		}
		this.deleteAt(index);
		return true;
	}

	private void deleteAt(int index) {
		int i = index;
		for (i = index; i < this.getKeyCount() - 1; ++i) {
			System.out.println(i);
			this.setKey(i, this.getKey(i + 1));
			this.setValue(i, this.getValue(i + 1));
		}
		this.setKey(i, null);
		this.setValue(i, null);
		--this.keyCount;
	}

	@Override
	protected void processChildrenTransfer(BTreeNode<TKey> borrower, BTreeNode<TKey> lender, int borrowIndex) {
		throw new UnsupportedOperationException();
	}

	@Override
	protected BTreeNode<TKey> processChildrenFusion(BTreeNode<TKey> leftChild, BTreeNode<TKey> rightChild) {
		throw new UnsupportedOperationException();
	}

	/**
	 * Notice that the key sunk from parent is be abandoned.
	 */
	@Override
	@SuppressWarnings("unchecked")
	protected void fusionWithSibling(TKey sinkKey, BTreeNode<TKey> rightSibling) {
		BTreeLeafNode<TKey, TValue> siblingLeaf = (BTreeLeafNode<TKey, TValue>) rightSibling;

		int j = this.getKeyCount();
		for (int i = 0; i < siblingLeaf.getKeyCount(); ++i) {
			this.setKey(j + i, siblingLeaf.getKey(i));
			this.setValue(j + i, siblingLeaf.getValue(i));
		}
		this.keyCount += siblingLeaf.getKeyCount();

		this.setRightSibling(siblingLeaf.rightSibling);
		if (siblingLeaf.rightSibling != null)
			siblingLeaf.rightSibling.setLeftSibling(this);
	}

	@Override
	@SuppressWarnings("unchecked")
	protected TKey transferFromSibling(TKey sinkKey, BTreeNode<TKey> sibling, int borrowIndex) {
		BTreeLeafNode<TKey, TValue> siblingNode = (BTreeLeafNode<TKey, TValue>) sibling;

		this.insertKey(siblingNode.getKey(borrowIndex), siblingNode.getValue(borrowIndex));
		siblingNode.deleteAt(borrowIndex);

		return borrowIndex == 0 ? sibling.getKey(0) : this.getKey(0);
	}

	@Override
	public String commit() {
		String result = "";
		for (int i = 0; i < values.length; i++) {
			if (values[i] == null) {
				break;
			}
			result += values[i].toString() + "\r\n";
		}
		return result;
	}

	@Override
	public BTreeLeafNode getSmallest() {
		return this;
	}

	// @Override
	// public String project(SelectColumns columns) {
	// String out = "";
	// for (int index = 0; index < this.getKeyCount(); ++index) {
	// if (filters.size() != 0) {
	// if (!filters.get(index)) {
	// continue;
	// }
	// }
	// TValue value = this.getValue(index);
	// if (value instanceof DBRecord) {
	// DBRecord record = (DBRecord) value;
	// String inc = record.project(columns);
	// out += inc + "\n";
	// } else {
	// out += this.getValue(index).toString() + " ";
	// }
	// }
	// filters = new ArrayList<>();
	// return out;
	// }

	// @Override
	// public void filter(ArrayList<DBCond> conditions) {
	// for (int index = 0; index < this.getKeyCount(); ++index) {
	// TValue value = this.getValue(index);
	// if (value instanceof DBRecord) {
	// DBRecord record = (DBRecord) value;
	// String inc = record.evaluate(conditions);
	// if (inc.equals("")) {
	// filters.add(false);
	// } else {
	// filters.add(true);
	// }
	// }
	// }
	// }
}