

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;

public class Table implements Serializable{
	String tableName;
	String clustringKey;
	Hashtable<String,String> colNameType;
	Vector <String> pageNames;
	Vector<Pair<String , String>> minMax;
	Vector<String> tableColumns;
	Vector<String> indexNames;
	
	
	public Table(String name , String clustringKey , Hashtable <String,String> colNameType) {
		this.tableName = name;
		this.clustringKey = clustringKey;
		this.colNameType = colNameType;
		this.pageNames = new Vector<String>();
		this.tableColumns = new Vector<String>();
		this.indexNames = new Vector<String>();
		this.minMax = new Vector<Pair<String , String>>();
	}
	
	public Vector<String> getPages() {
		return pageNames;
	}
	
	public  void saveTable() throws IOException, DBAppException{
		try {
	         FileOutputStream fileOut = new FileOutputStream("bin\\resources\\Tables\\" + this.tableName + ".class");
	         ObjectOutputStream out = new ObjectOutputStream(fileOut);
	         out.writeObject(this);
	         out.close();
	         fileOut.close();
	      } catch (IOException i) {
	         i.printStackTrace();
	      }
	}
	
	public static Table loadTable(String tableName) throws IOException, DBAppException{
		try {
	         FileInputStream fileIn = new FileInputStream("bin\\resources\\Tables\\" + tableName + ".class");
	         ObjectInputStream in = new ObjectInputStream(fileIn);
	         Table t = (Table) in.readObject();
	         in.close();
	         fileIn.close();
	         return t;
	      } catch (IOException i) {
	         i.printStackTrace();         
	      } catch (ClassNotFoundException c) {
	         System.out.println(tableName + " class not found");
	         c.printStackTrace();
	      }
		return null;
	}
	
}
