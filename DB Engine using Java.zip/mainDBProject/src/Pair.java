import java.io.Serializable;

public class Pair<A extends Comparable<A>, B extends Comparable<B>> implements Serializable{
    private A min;
    private B max;

    public Pair(A first, B second) {
        this.min = first;
        this.max = second;
    }

    public A getMin() {
        return min;
    }

    public void setMin(A first) {
        this.min = first;
    }

    public B getMax() {
        return max;
    }

    public void setMax(B second) {
        this.max = second;
    }
    
    public String toString() {
        return "(" + min + ", " + max + ")";
    }
}
