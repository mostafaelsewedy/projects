
public class TupleVector<E> extends java.util.Vector<E> {

	@Override
    public String toString() {
		
		String result = "";
		for (E element : this) {
			result = result + element + ",";
        }
        //AddCodeToMakeString
        return result;
    }
}
