import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Index implements Serializable{
	
	String name;
	BTree<?, TablePointer> tree;
	public Index(String name, BTree<?, TablePointer> bpt) {
		this.name = name;
		this.tree = bpt;
	}
	
	public  void saveIndex() throws IOException, DBAppException{
		try {
	         FileOutputStream fileOut = new FileOutputStream("bin\\resources\\Indecies\\" + this.name + ".class");
	         ObjectOutputStream out = new ObjectOutputStream(fileOut);
	         out.writeObject(this);
	         out.close();
	         fileOut.close();
	         System.out.println("Serialized data is saved in /tmp/employee.ser");
	      } catch (IOException i) {
	         i.printStackTrace();
	      }
	}
	
	public static Index loadIndex(String indexName) throws IOException, DBAppException{
		try {
	         FileInputStream fileIn = new FileInputStream("bin\\resources\\Indecies\\" + indexName + ".class");
	         ObjectInputStream in = new ObjectInputStream(fileIn);
	         Index i = (Index) in.readObject();
	         in.close();
	         fileIn.close();
	         return i;
	      } catch (IOException i) {
	         i.printStackTrace();         
	      } catch (ClassNotFoundException c) {
	         System.out.println("Employee class not found");
	         c.printStackTrace();
	      }
		return null;
	}
}
