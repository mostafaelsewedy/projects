
public enum OperatorsIn {
	
	
	
	GREATER_THAN(">"),
    GREATER_THAN_OR_EQUAL_TO(">="),
    LESS_THAN("<"),
    LESS_THAN_OR_EQUAL_TO("<="),
    NOT_EQUAL_TO("!="),
    EQUAL_TO("=");
	
	OperatorsIn(String symbol) {
		this.symbol = symbol;
	}
	
	public String getSymbol() {
        return symbol;
    }

	private final String symbol;
}
