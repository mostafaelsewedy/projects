import java.io.Serializable;

public class TablePointer implements Serializable{

	public String pageName;
	public int tupleIndex;
	
	
		public TablePointer(String pageName, int tupleIndex) {
			super();
			this.pageName = pageName;
			this.tupleIndex = tupleIndex;
		}
		
		public String toString() {
			return "Page: " + this.pageName + "  " + "Tuple number: " + this.tupleIndex;
		}
	
}
