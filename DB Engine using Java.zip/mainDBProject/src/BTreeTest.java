import java.util.ArrayList;
import java.util.Vector;

public class BTreeTest {
	public static void main(String[] args) {
//		IntegerBTree tree = (IntegerBTree) new BTree<Integer,Integer>();
//		TablePointer tp = new TablePointer("Student0",7);
//		TablePointer tp1 = new TablePointer("Student1",9);
//		TablePointer tp2 = new TablePointer("Student2",10);
//		TablePointer tp3 = new TablePointer("Student3",10);
//		tree.insert("hi",tp);
//		tree.insert(48,tp1);
//		tree.insert(48,tp);
//		tree.insert(33,tp2);
//		tree.insert(48,tp3);
//
//		tree.insert(50,tp);
//
//		tree.insert(15,tp);
//		tree.insert(18,tp);
//		tree.insert(20,tp);
//		tree.insert(21,tp);
//		tree.insert(31,tp);
//		tree.insert(45,tp);
//		tree.insert(47,tp);
//		tree.insert(52,tp);
//
//		tree.insert(30,tp);
//
//		tree.insert(19,tp);
//		tree.insert(22,tp);
//
//		tree.insert(11,tp);
//		tree.insert(13,tp);
//		tree.insert(16,tp);
//		tree.insert(17,tp);
//
//		tree.insert(1,tp);
//		tree.insert(2,tp);
//		tree.insert(3,tp);
//		tree.insert(4,tp);
//		tree.insert(5,tp);
//		tree.insert(6,tp);
//		tree.insert(7,tp);
//		tree.insert(8,tp);
//		tree.insert(9,tp);
		
//		tree.insert("hi",tp);
//		tree.insert("hey",tp1);
//		tree.insert("ho",tp);
//		tree.insert("he",tp2);
//		tree.insert("cri",tp3);
//
//		tree.insert("kri",tp);
//
//		tree.insert("fri",tp);
//		tree.insert("hi",tp2);
//		tree.insert("ti",tp);
//		tree.insert(21,tp);
//		tree.insert(31,tp);
//		tree.insert(45,tp);
//		tree.insert(47,tp);
//		tree.insert(52,tp);
//
//		tree.insert(30,tp);
//
//		tree.insert(19,tp);
//		tree.insert(22,tp);
//
//		tree.insert(11,tp);
//		tree.insert(13,tp);
//		tree.insert(16,tp);
//		tree.insert(17,tp);
//
//		tree.insert(1,tp);
//		tree.insert(2,tp);
//		tree.insert(3,tp);
//		tree.insert(4,tp);
//		tree.insert(5,tp);
//		tree.insert(6,tp);
//		tree.insert(7,tp);
//		tree.insert(8,tp);
//		tree.insert(9,tp);
		
//		tree.insert(10,3);
//		tree.insert(48,4);
//		tree.insert(23,5);
//		tree.insert(33,6);
//		tree.insert(12,7);
//
//		tree.insert(50,8);
//
//		tree.insert(15,9);
//		tree.insert(18,10);
//		tree.insert(20,11);
//		tree.insert(21,12);
//		tree.insert(31,13);
//		tree.insert(45,14);
//		tree.insert(47,15);
//		tree.insert(52,16);
//
//		tree.insert(30,17);
//
//		tree.insert(19,18);
//		tree.insert(22,19);
//
//		tree.insert(11,20);
//		tree.insert(13,21);
//		tree.insert(16,22);
//		tree.insert(17,23);
//
//		tree.insert(1);
//		tree.insert(2);
//		tree.insert(3);
//		tree.insert(4);
//		tree.insert(5);
//		tree.insert(6);
//		tree.insert(7);
//		tree.insert(8);
//		tree.insert(9);
//		tree.insert(3);
		

//		tree.print();
//		System.out.println(tree.search("hi"));
//		tree.delete("hi",tp);
//		tree.print();
//		System.out.println(tree.search("hi"));
//		Vector<TablePointer> pointer = tree.search("hi");
//		System.out.println(pointer);
//		System.out.println((tree.search(10)).get(0).pageName);
//		System.out.println((tree.search(48)).get(0).pageName);
//		System.out.println((tree.search(48)).get(1).pageName);
//		System.out.println((tree.search(48)).get(2).pageName);
//		 DBBTreeIterator iterator = new DBBTreeIterator(tree);
//		 iterator.print();
    }
}

class IntegerBTree extends BTree<Integer,Integer> {
	public void insert(int key) {
		this.insert(key);
	}

//	public void remove(int key) {
//		this.delete(key);
//	}
}

//class IntegerBTree extends BTree<Integer, Integer> {
//	public void insert(int key,int key2) {
//		this.insert(key, key);
//	}
//
//	public void remove(int key) {
//		this.delete(key);
//	}
//}
//
//class DoubleBTree extends BTree<Double , Vector<TablePointer>>{
//	public void insert(double key , TablePointer tablePointer) {
//		this.insert(key ,tablePointer);
//	}
//	
//	public void remove(double key) {
//		this.delete(key);
//	}
//}
//
//class StringBTree extends BTree<String , Vector<TablePointer>>{
//	public void insert(String key , TablePointer tablePointer) {
//		this.insert(key ,tablePointer);
//	}
//	
//	public void remove(String key) {
//		this.delete(key);
//	}
//}



