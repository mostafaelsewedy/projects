/** * @author Wael Abouelsaadat */




import java.util.Iterator;
import java.util.Random;
import java.util.Vector;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;




public class DBApp {

	
	

	public DBApp( ){
		
	}

	// this does whatever initialization you would like 
	// or leave it empty if there is no code you want to 
	// execute at application startup 
	public void init( ){
		
		
	}


	// following method creates one table only
	// strClusteringKeyColumn is the name of the column that will be the primary
	// key and the clustering column as well. The data type of that column will
	// be passed in htblColNameType
	// htblColNameValue will have the column name as key and the data 
	// type as value
	public void createTable(String strTableName, 
							String strClusteringKeyColumn,  
							Hashtable<String,String> htblColNameType) throws DBAppException, IOException{
		if(findTable(strTableName)) {
			throw new DBAppException("Cannot Create another table with this name");
		}
		Table t = new Table(strTableName,strClusteringKeyColumn,htblColNameType);
		t.saveTable();
		csvWriter(strTableName,strClusteringKeyColumn,htblColNameType);
	}
	
	
	//missing index part
	public void csvWriter(String strTableName,String strClusteringKeyColumn,Hashtable<String,String> htblColNameType) throws DBAppException {
		try {
			FileWriter fw = new FileWriter("bin\\metadata.csv", true);
			BufferedWriter bw = new BufferedWriter (fw);
			Table t = Table.loadTable(strTableName);
			
			Enumeration<String> s = htblColNameType.keys();
			while(s.hasMoreElements()) {
				String colName = s.nextElement();
				String dataType = htblColNameType.get(colName);
				String clust;
				if(colName.equals(strClusteringKeyColumn))
					clust = "True";
				else
					clust = "False";
				bw.write( strTableName + "," + colName + "," +  dataType + "," + clust + "," +"null" + "," + "null" + "\n");
				t.tableColumns.add(colName);
				t.saveTable();
			}
			
			bw.close();				
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	// following method creates a B+tree index 
	public void createIndex(String   strTableName,
							String   strColName,
							String   strIndexName) throws DBAppException, IOException{
		if(findIndex(strTableName ,strIndexName)){
			throw new DBAppException("index already exists");
		}
		updateIndexCSV(strTableName,strColName,strIndexName);
		Table t = Table.loadTable(strTableName);
		Vector <String> pageNames = t.getPages();
		int ps = pageNames.size();
		int columnIndex = t.tableColumns.indexOf(strColName);	
		String columnType = checkOneVariable(strTableName ,strColName , columnIndex);
		BTree tree;
		System.out.println(columnType);
		if(columnType.equals("java.lang.String")) {
			tree = new BTree<String,TablePointer>();
		}
		else if (columnType.equals("java.lang.Double")) {		
			tree = new  BTree<Double,TablePointer>();
		}
		else {
			 tree = new BTree<Integer,TablePointer>();
		}
		
		
		
		for(int i = 0 ; i<ps ; i++){
			try {
				//System.out.println(pageNames.get(i));
				Page p = Page.loadPage(pageNames.get(i) + "");
				Vector<TupleVector<String>> tuples  = p.getTuples();
				for(int j = 0; j<tuples.size();j++) {
					TupleVector<String> currentTuple = tuples.get(j);
					// insert into bpt 
					TablePointer tp = new TablePointer(p.getName(),j);
					Comparable key;
					if(columnType.equals("java.lang.String")) {
						 key = currentTuple.get(columnIndex);
					}
					else if (columnType.equals("java.lang.Double")) {		
						 key = getDoubleFromString(currentTuple.get(columnIndex)) ;
					}
					else {
						 key = getIntFromString(currentTuple.get(columnIndex));
					}
					
					tree.insert(key,tp);
				}
			}
			catch(IOException e){
				e.getMessage();
				break;
			}
		}
		
		Index index = new Index(strIndexName, tree);
		t.indexNames.add(index.name);
		t.saveTable();
		index.saveIndex();
	}
	
	public static void updateIndexCSV(String tableName,String columnName , String indexName) {
		try {
		    File file = new File("bin\\metadata.csv");
		    Path path = Paths.get("bin\\metadata.csv");
		    File tempFile = new File("bin\\metadata.csv.tmp");
		    BufferedReader br = new BufferedReader(new FileReader(file));
		    BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile));

		    String line;
		    while ((line = br.readLine()) != null) {
		        String[] sp = line.split(",");
		        if (sp[1].equals(columnName) && sp[0].equals(tableName)) {
		            sp[4] = indexName;
		            sp[5] = "B+ Tree";
		            line = String.join(",", sp);
		        }
		        bw.write(line);
		        bw.newLine(); // Write a newline after each line
		    }
		    
		    br.close();
		    
		    bw.close();
		    
		    // Replace the original file with the temporary file
		    
		    try {
		        Files.delete(path);
		        System.out.println("File deleted successfully.");
		        if (tempFile.renameTo(file)) {
		            System.out.println("Line overridden successfully.");
		        } else {
		            System.out.println("Failed to override the line.");
		        }
		    } catch (IOException e) {
		        System.out.println("Failed to delete the file: " + e.getMessage());
		    }
//		    if (file.delete()) {
//		        if (tempFile.renameTo(file)) {
//		            System.out.println("Line overridden successfully.");
//		        } else {
//		            System.out.println("Failed to override the line.");
//		        }
//		    } else {
//		        System.out.println("Failed to delete the original file: " + file.getAbsolutePath());
//		    }
		} catch (IOException e) {
		    e.printStackTrace();
		}
	}
	
	public static <T extends Comparable<T>> int compare(T obj1, T obj2) {
        return obj1.compareTo(obj2);
    }
	


	// following method inserts one row only. 
	// htblColNameValue must include a value for the primary key
	public void insertIntoTable(String strTableName, 
								Hashtable<String,Object>  htblColNameValue) throws DBAppException, IOException{
		
		if(!findTable(strTableName)) {
			throw new DBAppException("Cannot find this table");
		}
		if(!checkVariables(strTableName , htblColNameValue)) {
			throw new DBAppException("Column Types Incorrect!");
		}
		if(!checkPrimaryNull(strTableName,htblColNameValue)) {
			throw new DBAppException("You must put a value for primary key");
		}
		Table t = Table.loadTable(strTableName);
		int columnIndex = t.tableColumns.indexOf(t.clustringKey);
		String columnType = checkOneVariable(strTableName ,t.clustringKey , columnIndex);
		Comparable key = null;
		TupleVector<String> columnValues = new TupleVector<String>();
		Enumeration<String> s = htblColNameValue.keys();
		while(s.hasMoreElements()) {
			String colName = s.nextElement();
			String data = htblColNameValue.get(colName) + "";
			if(colName.equals(t.clustringKey)) {
				if(columnType.equals("java.lang.String")) {
					key = data;
				}
				else if (columnType.equals("java.lang.Double")) {		
					 key = getDoubleFromString(data);
				}
				else {
					 key = getIntFromString(data);
				}
			}
			columnValues.add(data);
		}
		
		String indexName = primaryHasIndex(strTableName ,t.clustringKey);
		if(indexName!= null) {
			System.out.println("used index");
			Index index = Index.loadIndex(indexName);
			BTree tree = index.tree;
			TablePointer pointer = tree.findClosest(key);
			Page p = Page.loadPage(pointer.pageName);
			if(pointer.pageName.equals(t.pageNames.get(t.pageNames.size() -1)) && pointer.tupleIndex == p.getTuples().size() -1) {
				p.getTuples().add(columnValues);
			}
			else {
				p.getTuples().add(pointer.tupleIndex, columnValues);
			}	
			p.savePage();
			if(columnType.equals("java.lang.String")) {
				key = key + "";
			}
			else if (columnType.equals("java.lang.Double")) {		
				 key = getDoubleFromString(key+"");
			}
			else {
				 key = getIntFromString(key + "");
			}
			
			if(p.getTuples().size()>p.getMaxSize()) {
				removeFromFullPage(t, p);
				updateIndex(t);
				return;
			}
			updateIndex(t);
		}
		else {
			System.out.println("didnt use index");
			insertHelper(strTableName , columnValues);
			updateIndex(t);
		}
	}
	
	
	public static void removeFromFullPage(Table t, Page p) throws IOException, DBAppException {
		TupleVector extraTuple = p.getTuples().get(p.getTuples().size() -1);
		int nextPageIndex = t.pageNames.indexOf(p.name)+1;
		p.getTuples().remove(p.getMaxSize());
		updateMinMax(t,p);
		p.savePage();
		p= null;
		if(nextPageIndex >= t.pageNames.size()) {
			System.out.println("inside catch 2");
			Page pNew = new Page(t.tableName + nextPageIndex); 
			System.out.println("created new Page");
			pNew.getTuples().add(extraTuple);
			t.pageNames.add(pNew.name);
			String minClustValue = pNew.getTuples().get(0).get(t.tableColumns.indexOf(t.clustringKey));
			String maxClustValue = pNew.getTuples().get(pNew.getTuples().size() -1).get(t.tableColumns.indexOf(t.clustringKey));
			Pair<String , String> minMaxPair = new Pair(minClustValue,maxClustValue);
			t.minMax.add(minMaxPair);
			pNew.savePage();
			updateMinMax(t,pNew);
			t.saveTable();
			pNew = null;
			return;
		}
		String nextPageName = t.pageNames.get(nextPageIndex);
		Page nextPage = p.loadPage(nextPageName);
		nextPage.getTuples().add(0, extraTuple);
		nextPage.savePage();
		updateMinMax(t,nextPage);
		if(nextPage.getTuples().size() >nextPage.getMaxSize()) {
			removeFromFullPage(t , nextPage);
		}
		
	}
	
	public static void insertHelper(String strTableName,TupleVector<String> tuple) throws IOException, DBAppException {
		System.out.println("im inserting " + tuple);
		Table t = Table.loadTable(strTableName);
		System.out.println(t.clustringKey);
		int columnIndex = t.tableColumns.indexOf(t.clustringKey);
		String columnType = checkOneVariable(strTableName ,t.clustringKey , columnIndex);
		Comparable key;
		if(columnType.equals("java.lang.String")) {
			 key = (String)tuple.get(columnIndex);
		}
		else if (columnType.equals("java.lang.Double")) {		
			 key = (double)getDoubleFromString(tuple.get(columnIndex));
		}
		else {
			 key = (int)getIntFromString(tuple.get(columnIndex));
		}
		Vector<String> allPages = t.pageNames;
		if(allPages.size() == 0){
			Page firstPage = new Page(strTableName + 0);
			firstPage.getTuples().add(tuple);
			t.getPages().add(firstPage.name);
			String minClustValue = firstPage.getTuples().get(0).get(columnIndex);
			String maxClustValue = firstPage.getTuples().get(firstPage.getTuples().size() -1).get(columnIndex);
			Pair<String , String> minMaxPair = new Pair(minClustValue,maxClustValue);
			t.minMax.add(minMaxPair);
			t.saveTable();
			firstPage.savePage();
			firstPage = null;
			return;
		}
		int hi = allPages.size()-1;
		int lo = 0;
		int i = lo + (hi- lo)/2;
		
			while(lo<=hi) {
				i = lo + (hi- lo)/2;
				System.out.println("hi : Page" + hi);
				System.out.println("lo : Page" + lo);
				System.out.println("i : Page" + i);
				
				
				System.out.println("inside page: " + allPages.get(i));
				
				Comparable key1 ;
				Comparable key2 ;
				if(columnType.equals("java.lang.String")) {
					key1 = (String)(t.minMax.get(i).getMin() + "");
					System.out.println(key1);
					key2 = (String)(t.minMax.get(i).getMax() + "");
					System.out.println(key2);
				}
				else if (columnType.equals("java.lang.Double")) {		
					key1 = getDoubleFromString(t.minMax.get(i).getMin() + "" );
					System.out.println(key1);
					key2 = getDoubleFromString(t.minMax.get(i).getMax() + "");
					System.out.println(key2);
				}
				else {
					key1 = getIntFromString(t.minMax.get(i).getMin() + "" );
					System.out.println(key1);
					key2 = getIntFromString(t.minMax.get(i).getMax() + "");
					System.out.println(key2);
				}
				
				if((compare(key,key1) ==0) || (compare(key,key2) ==0)) { 
					throw new DBAppException("this value already exists");
				}
				if(compare(key,key1)<0) {
					hi = i -1;
					System.out.println("pages hi: " + hi);
				}else
				{
					if(compare(key,key2)>0) {
						lo = i +1;
						System.out.println("pages lo: " + lo);
					}
					else {
						Page p = Page.loadPage(allPages.get(i));
						Vector tuples = p.getTuples();
						TupleVector t1 = (TupleVector) tuples.get(0);
						TupleVector t2 = (TupleVector) (tuples.get(tuples.size()-1));
						System.out.println("calling inside up: " + strTableName + " t: " + t + " key: " + key + " p: " + p.name  + " t1: " + 
								t1.get(columnIndex) + " t2: " + t2.get(columnIndex));
						try {
							binaryInsidePage(strTableName ,t ,columnIndex ,columnType, key ,tuple ,p, tuples , t1 ,t2);
						}
						catch(IOException e) {
							return;
						}
						return;
					}
				}
				
			}
			Page p;
			if(lo >= allPages.size()) {
				p = Page.loadPage(allPages.get(allPages.size()-1));
			}
			else{
				 p = Page.loadPage(allPages.get(lo));
			}
			Vector tuples = p.getTuples();	
			TupleVector t1 = (TupleVector) tuples.get(0);
			TupleVector t2 = (TupleVector) (tuples.get(tuples.size()-1));
			
			System.out.println("calling inside down: " + strTableName + " t: " + t + " key: " + key + " p: " + p.name  + " t1: " + 
					t1.get(columnIndex) + " t2: " + t2.get(columnIndex));
			try {
				binaryInsidePage(strTableName ,t ,columnIndex ,columnType, key , tuple ,p, tuples , t1 ,t2);
			}
			catch(IOException e) {
				return;
			}
			
			
		}

	
	public static void binaryInsidePage(String strTableName ,Table t ,int columnIndex ,String columnType, Comparable key ,TupleVector insertedTuple , Page p ,Vector tuples , TupleVector t1, TupleVector t2 ) throws DBAppException, IOException {
		System.out.println("entered method inside");
		int lo2 = tuples.indexOf(t1);
		int hi2 = tuples.indexOf(t2);
		int mid = lo2 + (hi2 - lo2)/2;;
		while(lo2<=hi2) {
			mid = lo2 + (hi2 - lo2)/2;
			Comparable midKey;
			TupleVector midTuple = (TupleVector) (tuples.get(mid));
			if(columnType.equals("java.lang.String")) {
				 midKey = midTuple.get(columnIndex) + "";
				System.out.println("key = " + midKey);
			}
			else if (columnType.equals("java.lang.Double")) {		
				 midKey = getDoubleFromString(midTuple.get(columnIndex) + "");
				System.out.println("key = " + midKey);
			}
			else {
				 midKey = getIntFromString(midTuple.get(columnIndex) + "");
				System.out.println("key = " + midKey);
			}
			if(compare(key,midKey)==0) {
				throw new DBAppException("this value already exists");
			}
			if(compare(key,midKey)<0) {
				hi2=mid -1;
			}else {
				if(compare(key,midKey)>0) {
					lo2=mid +1;
				}	
			}
		}
		tuples.insertElementAt(insertedTuple, lo2);
		System.out.println("Inserted into page!!!!!!!!!!!!!!!!!!!");
		if(p.getTuples().size()>p.getMaxSize()) {
			removeFromFullPage(t, p);
			return;
		}
		else {
			p.savePage();
			updateMinMax(t,p);
		}
		return;
	}
	
	public static void updateMinMax(Table t ,Page p) throws IOException, DBAppException {
		int index = t.pageNames.indexOf(p.name);
		t.minMax.get(index).setMin(p.getTuples().get(0).get(t.tableColumns.indexOf(t.clustringKey)) + "");
		t.minMax.get(index).setMax(p.getTuples().get(p.getTuples().size() -1).get(t.tableColumns.indexOf(t.clustringKey)) + "");
		t.saveTable();
	}

	
	//helper to get int from string
	public static int getIntFromString(String s) {
		String i = "";
		for(int c=0;c< s.length();c++ ) {
			if(s.charAt(c)>='0' && s.charAt(c)<= '9') {
				i+= s.charAt(c);
			}
		}
		int x = 0;
		x= Integer.parseInt(i);
		return x;
	}
	
	public static double getDoubleFromString(String s) {
		String i = "";
		for(int c=0;c< s.length();c++ ) {
			if(s.charAt(c)>='0' && s.charAt(c)<= '9' || s.charAt(c) == '.') {
				i+= s.charAt(c);
			}
		}
		double x = 0;
		x= Double.parseDouble(i);
		return x;
	}
	
	//helper
	public static boolean findTable(String tableName) {
		try {
			BufferedReader br = new BufferedReader(new FileReader("bin\\metadata.csv"));
			String line = br.readLine();
			while (line != null) {
				String[] sp = line.split(",");
				if (sp[0].equals(tableName)) {
					return true;
				}
				line = br.readLine();
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public static boolean findIndex(String tableName ,String indexName) {
		try {
			BufferedReader br = new BufferedReader(new FileReader("bin\\metadata.csv"));
			String line = br.readLine();
			while (line != null) {
				String[] sp = line.split(",");
				if (sp[0].equals(tableName) && sp[4].equals(indexName)) {
					return true;
				}
				line = br.readLine();
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	
	//helper
	public static boolean checkVariables(String tableName, Hashtable<String,Object> htblColNameValue) {
		boolean flag = true;
		Enumeration<String> s = htblColNameValue.keys();
		while(s.hasMoreElements()) {
			String colName = s.nextElement();
			String dataType = htblColNameValue.get(colName).getClass().getName();
			try {
				BufferedReader br = new BufferedReader(new FileReader("bin\\metadata.csv"));
				String line = br.readLine();
				
				while (line != null) {
					String[] sp = line.split(",");
					if(sp[0].equals(tableName)) {
						//System.out.println(tableName);
						if (sp[1].equals(colName)){
							//System.out.println(colName);
							if(sp[2].equals(dataType)) {
								//System.out.println(dataType);
								flag = true;
							}
							else {
								System.out.println(dataType);
								return false;
							}
						}
					}
					line = br.readLine();
				}
						
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return flag;
		
	}
	
	public static String checkOneVariable(String tableName, String columnName , int columnIndex) {
			try {
				BufferedReader br = new BufferedReader(new FileReader("bin\\metadata.csv"));
				String line = br.readLine();
				
				while (line != null) {
					String[] sp = line.split(",");
					if(sp[0].equals(tableName)) {
						if(sp[1].equals(columnName))
							return sp[2];
					}
					line = br.readLine();
					
				}
				br.close();
					
				
			} catch (IOException e) {
				e.printStackTrace();
			}
			return "";
	}
	
	
	//helper
	public static  boolean checkPrimaryNull(String tableName, Hashtable<String,Object> htblColNameValue) {
		try {
			BufferedReader br = new BufferedReader(new FileReader("bin\\metadata.csv"));
			String line = br.readLine();
			String ClustColName = "";
			while (line != null) {
				String[] sp = line.split(",");
				if(sp[3].equals("True") && sp[0].equals(tableName) ) {
					ClustColName = sp[1];
				}
				line = br.readLine();
			}
					
			br.close();
			if(htblColNameValue.get(ClustColName) == null) {
				return false;
			}
			else{
				return true;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
			
	}
	
	
	public static String getClusteringKey(String tableName, Hashtable<String,Object> htblColNameValue) {
		String s = "";
		try {
			BufferedReader br = new BufferedReader(new FileReader("bin\\metadata.csv"));
			String line = br.readLine();
			String ClustColName = "";
			while (line != null) {
				String[] sp = line.split(",");
				if(sp[3].equals("True") && sp[0].equals(tableName) ) {
					ClustColName = sp[1];
				}
				line = br.readLine();
			}
					
			br.close();
			s = (String) htblColNameValue.get(ClustColName);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return s;
	}
	
	
	// following method updates one row only
	// htblColNameValue holds the key and new value 
	// htblColNameValue will not include clustering key as column name
	// strClusteringKeyValue is the value to look for to find the row to update.
	public void updateTable(String strTableName, 
							String strClusteringKeyValue,
							Hashtable<String,Object> htblColNameValue   )  throws DBAppException, IOException{
	
		if(!findTable(strTableName)) {
			throw new DBAppException("Cannot find this table");
		}
		if(!checkVariables(strTableName , htblColNameValue)) {
			throw new DBAppException("Column Types Incorrect!");
		}
		
		
		Table t = Table.loadTable(strTableName);
		int clusterIndex = t.tableColumns.indexOf(t.clustringKey);
		String columnType = checkOneVariable(strTableName ,t.clustringKey , clusterIndex); 
		System.out.println(columnType);
		
		TupleVector<String> colNames = new TupleVector<String>();
		TupleVector<String> columnValues = new TupleVector<String>();
		Enumeration<String> s = htblColNameValue.keys();
		while(s.hasMoreElements()) {
			String colName = s.nextElement();
			String data = htblColNameValue.get(colName) + "";
				colNames.add(colName);
				columnValues.add(data);
		}
		//need to check if priamry has index!!!
		String indexName = primaryHasIndex(strTableName ,t.clustringKey);
		Comparable key;
		if(indexName != null) {
			System.out.println("used index");
			Index index = Index.loadIndex(indexName);
			BTree tree = index.tree;
			if(columnType.equals("java.lang.String")) {
				key = strClusteringKeyValue;
			}
			else if (columnType.equals("java.lang.Double")) {		
				key = getDoubleFromString(strClusteringKeyValue);
			}
			else {
				key = getIntFromString(strClusteringKeyValue);
			}
			
			Vector<TablePointer> pointer = tree.search(key);
			if(pointer != null) {
				String page = pointer.get(0).pageName;
				int tupleIndex = pointer.get(0).tupleIndex;
				Page p = Page.loadPage(page);
				for(int j = 0 ; j<colNames.size() ;j ++) {
					p.getTuples().get(tupleIndex).set(t.tableColumns.indexOf(colNames.get(j)), columnValues.get(j) + "");
				}		
				p.savePage();
				updateIndex(t);
			}
			else {
				return;
			}

		}
		else {
			System.out.println("didnt use index");
			if(columnType.equals("java.lang.String")) {
				updateHelper(strTableName ,columnType ,strClusteringKeyValue ,colNames , columnValues);
				updateIndex(t);
			}
			else if (columnType.equals("java.lang.Double")) {		
				updateHelper(strTableName ,columnType ,getDoubleFromString(strClusteringKeyValue) ,colNames , columnValues);
				updateIndex(t);
			}
			else {
				updateHelper(strTableName ,columnType ,getIntFromString(strClusteringKeyValue) ,colNames , columnValues);
				updateIndex(t);
			}
		}
	}
	
	public String primaryHasIndex(String tableName, String clusteringKey ){
			try {
				BufferedReader br = new BufferedReader(new FileReader("bin\\metadata.csv"));
				String line = br.readLine();
				
				while (line != null) {
					String[] sp = line.split(",");
					if(sp[0].equals(tableName)) {
						//System.out.println(tableName);
						if (sp[1].equals(clusteringKey)){
							//System.out.println(colName);
							if(!sp[4].equals("null")) {
								//System.out.println(sp[2]);
								return sp[4];
							}
						}
					}
					line = br.readLine();
				}
						
				br.close();
				return null;
			} catch (IOException e) {
				e.printStackTrace();
			}
		return null;
	}
	
	public static void updateHelper(String strTableName,String columnType ,Comparable key ,TupleVector<String> columnNames ,TupleVector<String> columnValues) throws IOException, DBAppException {
		System.out.println("im inserting " + columnValues);
		Table t = Table.loadTable(strTableName);
		int columnIndex = t.tableColumns.indexOf(t.clustringKey);		
		Vector<String> allPages = t.pageNames;
		if(allPages.size() == 0){
			return;
		}
		int hi = allPages.size()-1;
		int lo = 0;
		int i = lo + (hi- lo)/2;
		
			while(lo<=hi) {
				i = lo + (hi- lo)/2;
				System.out.println("hi : Page" + hi);
				System.out.println("lo : Page" + lo);
				System.out.println("i : Page" + i);
				Comparable key1;
				Comparable key2;
				if(columnType.equals("java.lang.String")) {
					key1 = (String)(t.minMax.get(i).getMin() + "");
					System.out.println(key1);
					key2 = (String)(t.minMax.get(i).getMax() + "");
					System.out.println(key2);
				}
				else if (columnType.equals("java.lang.Double")) {		
					key1 = getDoubleFromString(t.minMax.get(i).getMin() + "" );
					System.out.println(key1);
					key2 = getDoubleFromString(t.minMax.get(i).getMax() + "");
					System.out.println(key2);
				}
				else {
					key1 = getIntFromString(t.minMax.get(i).getMin() + "" );
					System.out.println(key1);
					key2 = getIntFromString(t.minMax.get(i).getMax() + "");
					System.out.println(key2);
				}
				System.out.println(key2);
				if(compare(key,key1) == 0 ) {
					Page p = Page.loadPage(allPages.get(i));
					System.out.println("inside page: " + allPages.get(i));
					Vector tuples = p.getTuples();
					TupleVector t1 = (TupleVector) tuples.get(0);
					TupleVector t2 = (TupleVector) (tuples.get(tuples.size()-1));
					for(int j = 0 ; j<columnNames.size() ;j ++) {
						p.getTuples().get(0).set(t.tableColumns.indexOf(columnNames.get(j)), columnValues.get(j) + "");
					}		
					p.savePage();
					return;
				}
				if(compare(key,key2) == 0) {
					Page p = Page.loadPage(allPages.get(i));
					System.out.println("inside page: " + allPages.get(i));
					Vector tuples = p.getTuples();
					TupleVector t1 = (TupleVector) tuples.get(0);
					TupleVector t2 = (TupleVector) (tuples.get(tuples.size()-1));
					for(int j = 0 ; j<columnNames.size() ;j ++) {
						p.getTuples().get(p.getTuples().size() -1).set(t.tableColumns.indexOf(columnNames.get(j)), columnValues.get(j) + "");
					}	
					p.savePage();
					return;
				}
				if(compare(key,key1) <0) {
					hi = i -1;
					System.out.println("pages hi: " + hi);
				}else
				{
					if(compare(key,key2) > 0) {
						lo = i +1;
						System.out.println("pages lo: " + lo);
					}
					else {
						Page p = Page.loadPage(allPages.get(i));
						System.out.println("inside page: " + allPages.get(i));
						Vector tuples = p.getTuples();
						TupleVector t1 = (TupleVector) tuples.get(0);
						TupleVector t2 = (TupleVector) (tuples.get(tuples.size()-1));
						System.out.println("calling inside up: " + strTableName + " t: " + t + " key: " + key + " p: " + p.name  + " t1: " + 
								t1.get(0) + " t2: " + t2.get(0));
						try {
							updateBinaryInsidePage(strTableName ,t ,columnIndex ,columnType , key , columnNames ,columnValues ,p, tuples , t1 ,t2);
						}
						catch(IOException e) {
							return;
						}
						return;
					}
				}
				
			}
			Page p;
			if(lo >= allPages.size()) {
				p = Page.loadPage(allPages.get(allPages.size()-1));
			}
			else{
				 p = Page.loadPage(allPages.get(lo));
			}
			Vector tuples = p.getTuples();	
			TupleVector t1 = (TupleVector) tuples.get(0);
			TupleVector t2 = (TupleVector) (tuples.get(tuples.size()-1));
			
			System.out.println("calling inside down: " + strTableName + " t: " + t + " key: " + key + " p: " + p.name  + " t1: " + 
					t1.get(0) + " t2: " + t2.get(0));
			try {
				updateBinaryInsidePage(strTableName ,t ,columnIndex ,columnType , key , columnNames ,columnValues ,p, tuples , t1 ,t2);
			}
			catch(IOException e) {
				return;
			}
			
			
		}
	
	
	public static void updateBinaryInsidePage(String strTableName ,Table t ,int columnIndex ,String columnType,  Comparable key ,TupleVector<String> columnNames,TupleVector columnValues , Page p ,Vector tuples , TupleVector t1, TupleVector t2 ) throws DBAppException, IOException {
		System.out.println("entered method inside");
		int lo2 = tuples.indexOf(t1);
		int hi2 = tuples.indexOf(t2);
		int mid = lo2 + (hi2 - lo2)/2;
		while(lo2<=hi2) {
			mid = lo2 + (hi2 - lo2)/2;

			TupleVector midTuple = (TupleVector) (tuples.get(mid));
			Comparable midKey;
			if(columnType.equals("java.lang.String")) {
				 midKey = midTuple.get(columnIndex) + "";
				System.out.println("key = " + midKey);
			}
			else if (columnType.equals("java.lang.Double")) {		
				 midKey = getDoubleFromString(midTuple.get(columnIndex) + "");
				System.out.println("key = " + midKey);
			}
			else {
				 midKey = getIntFromString(midTuple.get(columnIndex) + "");
				System.out.println("key = " + midKey);
			}
			if(compare(key,midKey) == 0) {
				for(int j = 0 ; j<columnNames.size() ;j ++) {
					p.getTuples().get(mid).set(t.tableColumns.indexOf(columnNames.get(j)), columnValues.get(j) + "");
				}		
				p.savePage();
				return;
			}
			if(compare(key,midKey) < 0) {
				hi2=mid -1;
			}else {
				if(compare(key,midKey) > 0) {
					lo2=mid +1;
				}	
			}
		}
		System.out.println("didnt do anything");
		return;
	}
	
	// following method could be used to delete one or more rows.
	// htblColNameValue holds the key and value. This will be used in search 
	// to identify which rows/tuples to delete. 	
	// htblColNameValue enteries are ANDED together
	public void deleteFromTable(String strTableName, 
								Hashtable<String,Object> htblColNameValue) throws DBAppException, IOException{
		if(!findTable(strTableName)) {
			throw new DBAppException("Cannot find this table");
		}
		if(!checkVariables(strTableName , htblColNameValue)) {
			throw new DBAppException("Column Types Incorrect!");
		}
		
		boolean primaryGiven = false;
		Table t = Table.loadTable(strTableName);
		int clusterIndex = t.tableColumns.indexOf(t.clustringKey);
		String columnType = checkOneVariable(strTableName ,t.clustringKey , clusterIndex); 
		System.out.println(columnType);
		Comparable key = null;
		
		TupleVector<String> colNames = new TupleVector<String>();
		TupleVector<String> columnValues = new TupleVector<String>();
		Enumeration<String> s = htblColNameValue.keys();
		
		if(!s.hasMoreElements()){
			Collection<String> pages = new Vector<String>();
			for(int i = 0 ; i<t.getPages().size() ; i++) {
				File serializedFile = new File("bin\\resources\\Pages\\" + t.getPages().get(i) + ".class");
				serializedFile.delete();
				System.out.println("removed from minMax");
				t.minMax.remove(t.getPages().indexOf(t.getPages().get(i)));
				t.getPages().remove(t.getPages().get(i));
				t.saveTable();
				pages.add(t.getPages().get(i));
			}
			t.getPages().removeAll(pages);
			t.saveTable();
		}
		
		while(s.hasMoreElements()) {
			String colName = s.nextElement();
			String data = htblColNameValue.get(colName) + "";
			if(colName.equals(t.clustringKey)) {
				primaryGiven = true;
				if(columnType.equals("java.lang.String")) {
					key = data;
				}
				else if (columnType.equals("java.lang.Double")) {		
					key = getDoubleFromString(data);
				}
				else {
					key = getIntFromString(data);
				}
				
			}
				colNames.add(colName);
				columnValues.add(data);
		}
		
		String columnWithIndex = variableHasIndex(strTableName ,colNames);
		int indexOfColumn = t.tableColumns.indexOf(columnWithIndex);
		String columnWithIndexType = checkOneVariable(strTableName ,columnWithIndex , indexOfColumn);
		String indexName = columnWithIndex + "Index";
		if(columnWithIndex != null) {
			System.out.println("used index");
			Index index = Index.loadIndex(indexName);
			BTree indexTree = index.tree;
			Comparable indexKey;
			if(columnWithIndexType.equals("java.lang.String")) {
				indexKey = columnValues.get(colNames.indexOf(columnWithIndex));
			}
			else if (columnWithIndexType.equals("java.lang.Double")) {		
				indexKey = getDoubleFromString(columnValues.get(colNames.indexOf(columnWithIndex)));
			}
			else {
				System.out.println(columnValues);
				indexKey = getIntFromString(columnValues.get(colNames.indexOf(columnWithIndex)));
			}
			
			Vector<TablePointer> pointers = indexTree.search(indexKey);
			Collection<TablePointer> pointersToBeDeleted = new Vector<TablePointer>(); 
			for(int i = 0 ; i<pointers.size() ;i++) {
				Page p =Page.loadPage(pointers.get(i).pageName);
				String currentPage = pointers.get(i).pageName;
				Collection<TupleVector<String>> tuplesToBeDeleted = new Vector<TupleVector<String>>();
				while (pointers.get(i).pageName.equals(currentPage)) {
					TupleVector<String> tuple = p.getTuples().get(pointers.get(i).tupleIndex);
					Comparable tupleColumn;
					Comparable value;
					boolean MatchDelete = true;
					int columnIndex;
					for(int j = 0 ; j<colNames.size() ;j++) {
						columnIndex = t.tableColumns.indexOf(colNames.get(j));
						String type = checkOneVariable(strTableName ,colNames.get(j), columnIndex); 
						if(type.equals("java.lang.String")) {
							tupleColumn = tuple.get(columnIndex) + "";
							value = columnValues.get(j);
						}
						else if (type.equals("java.lang.Double")) {
							tupleColumn = getDoubleFromString(tuple.get(columnIndex) + "");
							value = getDoubleFromString(columnValues.get(j));
						}
						else {
							tupleColumn = getIntFromString(tuple.get(columnIndex) + "");
							value = getIntFromString(columnValues.get(j));
						}
						if(compare(value,tupleColumn) != 0) {
							MatchDelete = false;
							System.out.println("doesnt match");
							break;
						}					
					}
					if(MatchDelete) {
						tuplesToBeDeleted.add(tuple);
						pointersToBeDeleted.add(pointers.get(i));
					}
					i++;
					if(i >= pointers.size()) {
						break;
					}
				}
				p.getTuples().removeAll(tuplesToBeDeleted);
				p.savePage();
				if(p.getTuples().size() == 0) {
					String pageName = p.name;
					System.out.println("removed from minMax");
					t.minMax.remove(t.getPages().indexOf(pageName));
					t.getPages().remove(pageName);
					t.saveTable();
					File serializedFile = new File("bin\\resources\\Pages\\" + pageName + ".class");
					serializedFile.delete();
				}
				
				i--;
			}
			
			System.out.println(pointersToBeDeleted);
			updateIndex(t);
			
		}
		else {
			System.out.println("didnt use index");
			if(primaryGiven) {
				deleteHelper(strTableName,columnType ,key ,colNames ,columnValues);
				updateIndex(t);
			}
			else {
				deleteIterateHelper(strTableName,colNames,columnValues);
				updateIndex(t);
			}
		}
	}
	
	public void updateIndex(Table t) throws DBAppException, IOException {
		    Vector<String> indexNames = t.indexNames;
		    for(String indexName : indexNames) {
		    	Index index = Index.loadIndex(indexName);
		    	String strColName = "";
		    	for(int j = 0 ; j<indexName.length() - 5 ;j++) {
		    		strColName += indexName.charAt(j);
		    	}
		    	String strTableName = t.tableName;
				Vector <String> pageNames = t.getPages();
				int pageNamesSize = pageNames.size();
				int columnIndex = t.tableColumns.indexOf(strColName);	
				String columnType = checkOneVariable(strTableName ,strColName , columnIndex);
				BTree tree;
				System.out.println(columnType);
				if(columnType.equals("java.lang.String")) {
					tree = new BTree<String,TablePointer>();
				}
				else if (columnType.equals("java.lang.Double")) {		
					tree = new  BTree<Double,TablePointer>();
				}
				else {
					 tree = new BTree<Integer,TablePointer>();
				}
				
				for(int i = 0 ; i<pageNamesSize ; i++){
					try {
						//System.out.println(pageNames.get(i));
						Page p = Page.loadPage(pageNames.get(i) + "");
						Vector<TupleVector<String>> tuples  = p.getTuples();
						for(int j = 0; j<tuples.size();j++) {
							TupleVector<String> currentTuple = tuples.get(j);
							// insert into bpt 
							TablePointer tp = new TablePointer(p.getName(),j);
							Comparable key;
							if(columnType.equals("java.lang.String")) {
								 key = currentTuple.get(columnIndex);
							}
							else if (columnType.equals("java.lang.Double")) {		
								 key = getDoubleFromString(currentTuple.get(columnIndex)) ;
							}
							else {
								 key = getIntFromString(currentTuple.get(columnIndex));
							}
							
							tree.insert(key,tp);
						}
					}
					catch(IOException e){
						e.getMessage();
						break;
					}
				}
				index.tree = tree;
				index.saveIndex();
				System.out.println("index " + index.name + "updated");
		    }
			
		}
	
	
	public String variableHasIndex(String tableName ,TupleVector<String> colNames) {
		for(int i = 0 ; i<colNames.size() ; i++) {
			try {
				BufferedReader br = new BufferedReader(new FileReader("bin\\metadata.csv"));
				String line = br.readLine();
				
				while (line != null) {
					String[] sp = line.split(",");
					if(sp[0].equals(tableName)) {
						//System.out.println(tableName);
						if (sp[1].equals(colNames.get(i))){
							//System.out.println(colName);
							if(!sp[4].equals("null")) {
//								System.out.println(sp[1]);
								return sp[1];
							}
						}
					}
					line = br.readLine();
				}
						
				br.close();
				return null;
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	
	public static void deleteHelper(String strTableName,String columnType ,Comparable key ,TupleVector<String> columnNames ,TupleVector<String> columnValues) throws IOException, DBAppException {
		System.out.println("im deleting " + columnValues);
		Table t = Table.loadTable(strTableName);
		int columnIndex = t.tableColumns.indexOf(t.clustringKey);		
		Vector<String> allPages = t.pageNames;
		if(allPages.size() == 0){
			return;
		}
		int hi = allPages.size()-1;
		int lo = 0;
		int i = lo + (hi- lo)/2;
		
			while(lo<=hi) {
				i = lo + (hi- lo)/2;
				System.out.println("hi : Page" + hi);
				System.out.println("lo : Page" + lo);
				System.out.println("i : Page" + i);
				
				
				Comparable key1;
				Comparable key2;
				if(columnType.equals("java.lang.String")) {
					key1 = (String)(t.minMax.get(i).getMin() + "");
					System.out.println(key1);
					key2 = (String)(t.minMax.get(i).getMax() + "");
					System.out.println(key2);
				}
				else if (columnType.equals("java.lang.Double")) {		
					key1 = getDoubleFromString(t.minMax.get(i).getMin() + "" );
					System.out.println(key1);
					key2 = getDoubleFromString(t.minMax.get(i).getMax() + "");
					System.out.println(key2);
				}
				else {
					key1 = getIntFromString(t.minMax.get(i).getMin() + "" );
					System.out.println(key1);
					key2 = getIntFromString(t.minMax.get(i).getMax() + "");
					System.out.println(key2);
				}
				if(compare(key,key1) == 0 ) {
					Page p = Page.loadPage(allPages.get(i));
					Vector tuples = p.getTuples();
					TupleVector t1 = (TupleVector) tuples.get(0);
					TupleVector t2 = (TupleVector) (tuples.get(tuples.size()-1));
					int index;
					Comparable tupleColumn;
					Comparable value;
					boolean MatchDelete = true;
					for(int j = 0 ; j<columnNames.size() ;j++) {
						index = t.tableColumns.indexOf(columnNames.get(j));
						String type = checkOneVariable(strTableName ,columnNames.get(j), index); 
						if(type.equals("java.lang.String")) {
							tupleColumn = t1.get(index) + "";
							value = columnValues.get(j);
						}
						else if (type.equals("java.lang.Double")) {
							tupleColumn = getDoubleFromString(t1.get(index) + "");
							value = getDoubleFromString(columnValues.get(j));
						}
						else {
							tupleColumn = getIntFromString(t1.get(index) + "");
							value = getIntFromString(columnValues.get(j));
						}
						if(compare(value,tupleColumn) != 0) {
							MatchDelete = false;
							System.out.println("doesnt match");
							return;
						}					
					}
					if(MatchDelete) {
						p.getTuples().remove(t1);
						updateMinMax(t,p);
						p.savePage();
						String pageName = p.name;
						System.out.println(pageName);
						if(p.getTuples().size() == 0) {
							System.out.println("removed from minMax");
							t.minMax.remove(t.getPages().indexOf(pageName));
							t.getPages().remove(pageName);
							t.saveTable();
							File serializedFile = new File("bin\\resources\\Pages\\" + pageName + ".class");
							serializedFile.delete();
						}
						
						return;
					}
				}
				if(compare(key,key2) == 0) {
					Page p = Page.loadPage(allPages.get(i));
					Vector tuples = p.getTuples();
					TupleVector t1 = (TupleVector) tuples.get(0);
					TupleVector t2 = (TupleVector) (tuples.get(tuples.size()-1));
					int index;
					Comparable tupleColumn;
					Comparable value;
					boolean MatchDelete = true;
					for(int j = 0 ; j<columnNames.size() ;j++) {
						index = t.tableColumns.indexOf(columnNames.get(j));
						String type = checkOneVariable(strTableName ,columnNames.get(j), index); 
						if(type.equals("java.lang.String")) {
							tupleColumn = t2.get(index) + "";
							value = columnValues.get(j);
						}
						else if (type.equals("java.lang.Double")) {
							tupleColumn = getDoubleFromString(t2.get(index) + "");
							value = getDoubleFromString(columnValues.get(j));
						}
						else {
							tupleColumn = getIntFromString(t2.get(index) + "");
							value = getIntFromString(columnValues.get(j));
						}
						System.out.println("column: " + tupleColumn + "  " + "value: " + value);
						if(compare(value,tupleColumn) != 0) {
							MatchDelete = false;
							System.out.println("doesnt match");
							return;
						}					
					}
					if(MatchDelete) {
						p.getTuples().remove(t2);
						updateMinMax(t,p);
						p.savePage();
						String pageName = p.name;
						System.out.println(pageName);
						if(p.getTuples().size() == 0) {
							System.out.println("removed from minMax");					
							t.minMax.remove(t.getPages().indexOf(pageName));
							t.getPages().remove(pageName);
							t.saveTable();
							File serializedFile = new File("bin\\resources\\Pages\\" + pageName + ".class");
							serializedFile.delete();
						}
						
						return;
					}
				}
				if(compare(key,key1) <0) {
					hi = i -1;
					System.out.println("pages hi: " + hi);
				}else
				{
					if(compare(key,key2) > 0) {
						lo = i +1;
						System.out.println("pages lo: " + lo);
					}
					else {
						Page p = Page.loadPage(allPages.get(i));
						Vector tuples = p.getTuples();
						TupleVector t1 = (TupleVector) tuples.get(0);
						TupleVector t2 = (TupleVector) (tuples.get(tuples.size()-1));
						System.out.println("calling inside up: " + strTableName + " t: " + t + " key: " + key + " p: " + p.name  + " t1: " + 
								t1.get(0) + " t2: " + t2.get(0));
						try {
							deleteBinaryInsidePage(strTableName ,t ,columnIndex ,columnType , key , columnNames ,columnValues ,p, tuples , t1 ,t2);
						}
						catch(IOException e) {
							return;
						}
						return;
					}
				}
				
			}
			Page p;
			if(lo >= allPages.size()) {
				p = Page.loadPage(allPages.get(allPages.size()-1));
			}
			else{
				 p = Page.loadPage(allPages.get(lo));
			}
			Vector tuples = p.getTuples();	
			TupleVector t1 = (TupleVector) tuples.get(0);
			TupleVector t2 = (TupleVector) (tuples.get(tuples.size()-1));
			
			System.out.println("calling inside down: " + strTableName + " t: " + t + " key: " + key + " p: " + p.name  + " t1: " + 
					t1.get(0) + " t2: " + t2.get(0));
			try {
				deleteBinaryInsidePage(strTableName ,t ,columnIndex ,columnType , key , columnNames ,columnValues ,p, tuples , t1 ,t2);
			}
			catch(IOException e) {
				return;
			}
			
			
		}
	
	public static void deleteBinaryInsidePage(String strTableName ,Table t ,int columnIndex ,String columnType,  Comparable key ,TupleVector<String> columnNames,TupleVector<String> columnValues , Page p ,Vector tuples , TupleVector t1, TupleVector t2 ) throws DBAppException, IOException {
		System.out.println("entered method inside");
		int lo2 = tuples.indexOf(t1);
		int hi2 = tuples.indexOf(t2);
		int mid = lo2 + (hi2 - lo2)/2;
		while(lo2<=hi2) {
			mid = lo2 + (hi2 - lo2)/2;

			TupleVector midTuple = (TupleVector) (tuples.get(mid));
			Comparable midKey;
			if(columnType.equals("java.lang.String")) {
				 midKey = midTuple.get(columnIndex) + "";
				System.out.println("key = " + midKey);
			}
			else if (columnType.equals("java.lang.Double")) {		
				 midKey = getDoubleFromString(midTuple.get(columnIndex) + "");
				System.out.println("key = " + midKey);
			}
			else {
				 midKey = getIntFromString(midTuple.get(columnIndex) + "");
				System.out.println("key = " + midKey);
			}
			if(compare(key,midKey) == 0) {
				int index;
				Comparable tupleColumn;
				Comparable value;
				boolean MatchDelete = true;
				for(int j = 0 ; j<columnNames.size() ;j++) {
					index = t.tableColumns.indexOf(columnNames.get(j));
					String type = checkOneVariable(strTableName ,columnNames.get(j), index); 
					if(type.equals("java.lang.String")) {
						tupleColumn = midTuple.get(index) + "";
						value = columnValues.get(j);
					}
					else if (type.equals("java.lang.Double")) {
						tupleColumn = getDoubleFromString(midTuple.get(index) + "");
						value = getDoubleFromString(columnValues.get(j));
					}
					else {
						tupleColumn = getIntFromString(midTuple.get(index) + "");
						value = getIntFromString(columnValues.get(j));
					}
					if(compare(value,tupleColumn) != 0) {
						MatchDelete = false;
						System.out.println("doesnt match");
						return;
					}					
				}
				if(MatchDelete) {
					p.getTuples().remove(midTuple);
					updateMinMax(t,p);
					p.savePage();
					String pageName = p.name;
					System.out.println(pageName);
					if(p.getTuples().size() == 0) {
						System.out.println("removed from minMax");
						t.minMax.remove(t.getPages().indexOf(pageName));
						t.getPages().remove(pageName);	
						t.saveTable();
						File serializedFile = new File("bin\\resources\\Pages\\" + pageName + ".class");
						serializedFile.delete();
					}
					
					return;
				}
			}
			if(compare(key,midKey) < 0) {
				hi2=mid -1;
			}else {
				if(compare(key,midKey) > 0) {
					lo2=mid +1;
				}	
			}
		}
		System.out.println("didnt do anything");
		return;
	}
	
	public void deleteIterateHelper(String strTableName,TupleVector<String> colNames,TupleVector<String> columnValues) throws IOException, DBAppException{
		Table t = Table.loadTable(strTableName);
		Vector<String> allPages = t.pageNames;
		int index;
		Comparable value;
		Comparable tupleColumn;
		if(allPages.size() == 0){
			return;
		}
		Collection<String> pagesDeleted = new Vector<String>();
		for(String pageName : allPages) {
			Page p = Page.loadPage(pageName);
			Vector<TupleVector<String>> tuples = p.getTuples();
			Collection<TupleVector<String>> tuplesToBeDeleted = new Vector<TupleVector<String>>();
			for(TupleVector<String> tuple : tuples) {
				boolean MatchDelete = true;
				for(int i = 0 ; i<colNames.size() ;i++) {
					index = t.tableColumns.indexOf(colNames.get(i));
					String columnType = checkOneVariable(strTableName ,colNames.get(i), index); 
					if(columnType.equals("java.lang.String")) {
						tupleColumn = tuple.get(index);
						value = columnValues.get(i);
					}
					else if (columnType.equals("java.lang.Double")) {
						tupleColumn = getDoubleFromString(tuple.get(index));
						value = getDoubleFromString(columnValues.get(i));
					}
					else {
						tupleColumn = getIntFromString(tuple.get(index));
						value = getIntFromString(columnValues.get(i));
					}
					if(compare(value,tupleColumn) != 0) {
						MatchDelete = false;
						break;
					}
										
				}
				if(MatchDelete){
					tuplesToBeDeleted.add(tuple);
				}
			}
			p.getTuples().removeAll(tuplesToBeDeleted);
			if(p.getTuples().size() == 0) {
				String pName= p.name;
				System.out.println("removed from minMax");
				t.minMax.remove(t.getPages().indexOf(pName));
				t.getPages().remove(pName);
				t.saveTable();
				File serializedFile = new File("bin\\resources\\Pages\\" + pName + ".class");
				serializedFile.delete();
				continue;
			}
			p.savePage();
			System.out.println("deleted from page " + p.name);
		}
		t.getPages().removeAll(pagesDeleted);
		t.saveTable();
		
	}
	



	public Iterator selectFromTable(SQLTerm[] arrSQLTerms, 
									String[]  strarrOperators) throws DBAppException, IOException{
		ArrayList<String> numOfTables = new ArrayList<String>();
		boolean termHasPrimary = false;
		boolean containsOR = false;
		String indexToUse = null;
		String columnWithIndex = null;
		TupleVector<String> colNames = new TupleVector<String>();
		TupleVector<String> columnValues = new TupleVector<String>();
		TupleVector<String> operatorsIn = new TupleVector<String>();
		
		for(int i = 0 ; i<arrSQLTerms.length ; i++) {
			Hashtable htblColNameValue = new Hashtable( );
			String strTableName = arrSQLTerms[i]._strTableName;
			if(numOfTables.size() == 0) {
				numOfTables.add(strTableName);
			}
			if(numOfTables.get(0).equals(strTableName)) {
				
			}
			else {
				numOfTables.add(strTableName);
			}
			
			if(numOfTables.size()>1) {
				throw new DBAppException("More than 1 table given");
			}
			if(!(arrSQLTerms[i]._strOperator.equals(">") || arrSQLTerms[i]._strOperator.equals(">=") || arrSQLTerms[i]._strOperator.equals("<")
					|| arrSQLTerms[i]._strOperator.equals("<=") || arrSQLTerms[i]._strOperator.equals("=") || arrSQLTerms[i]._strOperator.equals("!="))) {
				throw new DBAppException("we dont support this op");
			}
			htblColNameValue.put(arrSQLTerms[i]._strColumnName,arrSQLTerms[i]._objValue);
			colNames.add(arrSQLTerms[i]._strColumnName);
			columnValues.add(arrSQLTerms[i]._objValue + "");
			operatorsIn.add(arrSQLTerms[i]._strOperator);
			if(!findTable(strTableName)) {
				throw new DBAppException("Cannot find this table");
			}
			if(!checkVariables(strTableName , htblColNameValue)) {
				throw new DBAppException("Column Types Incorrect!");
			}
		}
		
		if((strarrOperators.length == 0 && strarrOperators == null) && arrSQLTerms.length > 1) {
			throw new DBAppException("cant have two terms without operators");
		}
		
		
		
		String tableName = arrSQLTerms[0]._strTableName;
		Table t = Table.loadTable(tableName);
		int indexOfColumn ;
		String columnWithIndexType = null;
		for(int i = 0 ; i<arrSQLTerms.length ;i++) {
			if(arrSQLTerms[i]._strColumnName.equals(t.clustringKey)) {
				termHasPrimary = true;
			}
		}
		
		
		if(termHasPrimary) {
			indexToUse = primaryHasIndex(tableName ,t.clustringKey);
			if(indexToUse != null)
			columnWithIndex = t.clustringKey;
			indexOfColumn = t.tableColumns.indexOf(columnWithIndex);
			columnWithIndexType = checkOneVariable(tableName ,columnWithIndex , indexOfColumn);
		}
		
		if(indexToUse == null) {
			columnWithIndex = variableHasIndex(tableName ,colNames);
			indexOfColumn = t.tableColumns.indexOf(columnWithIndex);
			columnWithIndexType = checkOneVariable(tableName ,columnWithIndex , indexOfColumn);
			indexToUse = columnWithIndex + "Index";
		}
		System.out.println(columnWithIndex);
		for(int i  = 0 ; i<strarrOperators.length ; i++) {
			if(strarrOperators[i].equals("OR") || strarrOperators[i].equals("XOR")) {
				containsOR = true;
			}
		}
		if(containsOR) {
			columnWithIndex = null;
		}
		if(columnWithIndex != null) {

			System.out.println("used index");
			Index index = Index.loadIndex(indexToUse);
			BTree indexTree = index.tree;
			Comparable indexValue = null;
			String indexOperator = null;
			Vector<TablePointer> pointersToProcess = new Vector<TablePointer>();
			Vector<TupleVector<String>> tuplesToBeProcessed = new Vector<TupleVector<String>>();
			for(int j = 0 ; j<arrSQLTerms.length ; j++) {
				if(arrSQLTerms[j]._strColumnName.equals(columnWithIndex)) {
					indexOperator = arrSQLTerms[j]._strOperator;
					if(columnWithIndexType.equals("java.lang.String")) {
						indexValue = (String) arrSQLTerms[j]._objValue;
					}
					else if (columnWithIndexType.equals("java.lang.Double")) {
						indexValue = (Double) arrSQLTerms[j]._objValue;
					}
					else {
						indexValue = (int) arrSQLTerms[j]._objValue;
					}
				}
			}
			if(indexOperator.equals(OperatorsIn.EQUAL_TO.getSymbol())) {
				pointersToProcess = indexTree.findEqual(indexValue);
				System.out.println("pointers size: " + pointersToProcess.size());
			}
			else if(indexOperator.equals(OperatorsIn.NOT_EQUAL_TO.getSymbol())) {
				pointersToProcess = indexTree.findNotEqual(indexValue);
			}
			else if(indexOperator.equals(OperatorsIn.GREATER_THAN.getSymbol())) {
				pointersToProcess = indexTree.findGreater(indexValue);
			}
			else if(indexOperator.equals(OperatorsIn.GREATER_THAN_OR_EQUAL_TO.getSymbol())) {
				pointersToProcess = indexTree.findGreaterEqual(indexValue);
			}
			else if(indexOperator.equals(OperatorsIn.LESS_THAN.getSymbol())) {
				pointersToProcess = indexTree.findSmaller(indexValue);
			}
			else if(indexOperator.equals(OperatorsIn.LESS_THAN_OR_EQUAL_TO.getSymbol())) {
				pointersToProcess = indexTree.findSmallerEqual(indexValue);
			}
			
			tuplesToBeProcessed = new Vector<TupleVector<String>>();
			for(int i = 0 ; i<pointersToProcess.size() ;i++) {
				Page p =Page.loadPage(pointersToProcess.get(i).pageName);
				String currentPage = pointersToProcess.get(i).pageName;
				while (pointersToProcess.get(i).pageName.equals(currentPage)) {
					System.out.println(i);
					System.out.println(pointersToProcess.get(i).pageName);
					TupleVector<String> tuple = p.getTuples().get(pointersToProcess.get(i).tupleIndex);
					tuplesToBeProcessed.add(tuple);
					i++;
					if(i >= pointersToProcess.size()) {
						break;
					}

					}
				i--;
				}
			System.out.println("tuplesToBeProcessed size: " + tuplesToBeProcessed.size());
			if(tuplesToBeProcessed.size() == 0) {
				return null;
			}
			ArrayList<TupleVector<String>> tuplesToBeSelected = new ArrayList<TupleVector<String>>();
			int currIndex;
			Comparable tupleColumn;
			Comparable value;
				for(TupleVector<String> tuple : tuplesToBeProcessed) {
					ArrayList<Boolean> booleans  = new ArrayList<Boolean>();
					for(int i = 0 ; i<colNames.size() ;i++) {
						currIndex = t.tableColumns.indexOf(colNames.get(i));
						String columnType = checkOneVariable(tableName ,colNames.get(i), currIndex); 
						if(columnType.equals("java.lang.String")) {
							tupleColumn = tuple.get(currIndex);
							value = columnValues.get(i);
						}
						else if (columnType.equals("java.lang.Double")) {
							tupleColumn = getDoubleFromString(tuple.get(currIndex));
							value = getDoubleFromString(columnValues.get(i));
						}
						else {
							tupleColumn = getIntFromString(tuple.get(currIndex));
							value = getIntFromString(columnValues.get(i));
						}
						if(operatorsIn.get(i).equals(OperatorsIn.EQUAL_TO.getSymbol())) {
							boolean flag  = true;
							if(!(compare(value,tupleColumn) == 0)) {
								flag = false;
							}
							booleans.add(flag);
						}
						else if(operatorsIn.get(i).equals(OperatorsIn.NOT_EQUAL_TO.getSymbol())) {
							boolean flag  = true;
							if(!(compare(value,tupleColumn) != 0)) {
								flag = false;
							}
							booleans.add(flag);
						}
						else if(operatorsIn.get(i).equals(OperatorsIn.GREATER_THAN.getSymbol())) {
							boolean flag  = true;
							if(!(compare(value,tupleColumn) < 0)) {
								flag = false;
							}
							booleans.add(flag);
						}
						else if(operatorsIn.get(i).equals(OperatorsIn.GREATER_THAN_OR_EQUAL_TO.getSymbol())) {
							boolean flag  = true;
							if(!(compare(value,tupleColumn) < 0 || compare(value,tupleColumn) == 0 )) {
								flag = false;
							}
							booleans.add(flag);
						}
						else if(operatorsIn.get(i).equals(OperatorsIn.LESS_THAN.getSymbol())) {
							boolean flag  = true;
							if(!(compare(value,tupleColumn) > 0)) {
								flag = false;
							}
							booleans.add(flag);
						}
						else if(operatorsIn.get(i).equals(OperatorsIn.LESS_THAN_OR_EQUAL_TO.getSymbol())) {
							boolean flag  = true;
							if(!(compare(value,tupleColumn) > 0 || compare(value,tupleColumn) == 0 )) {
								flag = false;
							}
							booleans.add(flag);
						}					
					}
					boolean result = booleans.get(0);
					for (int i = 0; i < strarrOperators.length; i++) {
			            String operator = strarrOperators[i];
			            boolean nextBoolean = booleans.get(i + 1);

			            // Apply the operator to the current result and the next boolean
			            switch (operator) {
			                case "AND":
			                    result = result && nextBoolean;
			                    break;
			                case "OR":
			                    result = result || nextBoolean;
			                    break;
			                case "XOR":
			                    result = result ^ nextBoolean;
			                    break;
			                default:
			                    throw new IllegalArgumentException("Invalid operator: " + operator);
			            }
			        }
					if(result == true) {
						tuplesToBeSelected.add(tuple);
					}
			    }
		 Iterator<TupleVector<String>> it = tuplesToBeSelected.iterator();
		 return it;
		
	}
		else {
			System.out.println("didnt use index");
			return selectIterateHelper(tableName,colNames,columnValues,operatorsIn,strarrOperators);
		}
	}
	
	public Iterator selectIterateHelper(String strTableName,TupleVector<String> colNames,TupleVector<String> columnValues,TupleVector<String> operatorsIn ,String[] operators) throws IOException, DBAppException{
		Table t = Table.loadTable(strTableName);
		Vector<String> allPages = t.pageNames;
		int index;
		Comparable value;
		Comparable tupleColumn;
		ArrayList<TupleVector<String>> tuplesToBeSelected = new ArrayList<TupleVector<String>>();
		if(allPages.size() == 0){
			return null;
		}
		for(String pageName : allPages) {
			Page p = Page.loadPage(pageName);
			Vector<TupleVector<String>> tuples = p.getTuples();
			for(TupleVector<String> tuple : tuples) {
				boolean MatchDelete = true;
				ArrayList<Boolean> booleans  = new ArrayList<Boolean>();
				for(int i = 0 ; i<colNames.size() ;i++) {
					index = t.tableColumns.indexOf(colNames.get(i));
					String columnType = checkOneVariable(strTableName ,colNames.get(i), index); 
					if(columnType.equals("java.lang.String")) {
						tupleColumn = tuple.get(index);
						value = columnValues.get(i);
					}
					else if (columnType.equals("java.lang.Double")) {
						tupleColumn = getDoubleFromString(tuple.get(index));
						value = getDoubleFromString(columnValues.get(i));
					}
					else {
						tupleColumn = getIntFromString(tuple.get(index));
						value = getIntFromString(columnValues.get(i));
					}
					if(operatorsIn.get(i).equals(OperatorsIn.EQUAL_TO.getSymbol())) {
						boolean flag  = true;
						if(!(compare(value,tupleColumn) == 0)) {
							flag = false;
						}
						booleans.add(flag);
					}
					else if(operatorsIn.get(i).equals(OperatorsIn.NOT_EQUAL_TO.getSymbol())) {
						boolean flag  = true;
						if(!(compare(value,tupleColumn) != 0)) {
							flag = false;
						}
						booleans.add(flag);
					}
					else if(operatorsIn.get(i).equals(OperatorsIn.GREATER_THAN.getSymbol())) {
						boolean flag  = true;
						if(!(compare(value,tupleColumn) < 0)) {
							flag = false;
						}
						booleans.add(flag);
					}
					else if(operatorsIn.get(i).equals(OperatorsIn.GREATER_THAN_OR_EQUAL_TO.getSymbol())) {
						boolean flag  = true;
						if(!(compare(value,tupleColumn) < 0 || compare(value,tupleColumn) == 0 )) {
							flag = false;
						}
						booleans.add(flag);
					}
					else if(operatorsIn.get(i).equals(OperatorsIn.LESS_THAN.getSymbol())) {
						boolean flag  = true;
						if(!(compare(value,tupleColumn) > 0)) {
							flag = false;
						}
						booleans.add(flag);
					}
					else if(operatorsIn.get(i).equals(OperatorsIn.LESS_THAN_OR_EQUAL_TO.getSymbol())) {
						boolean flag  = true;
						if(!(compare(value,tupleColumn) > 0 || compare(value,tupleColumn) == 0 )) {
							flag = false;
						}
						booleans.add(flag);
					}					
				}
				boolean result = booleans.get(0);
				for (int i = 0; i < operators.length; i++) {
		            String operator = operators[i];
		            boolean nextBoolean = booleans.get(i + 1);

		            // Apply the operator to the current result and the next boolean
		            switch (operator) {
		                case "AND":
		                    result = result && nextBoolean;
		                    break;
		                case "OR":
		                    result = result || nextBoolean;
		                    break;
		                case "XOR":
		                    result = result ^ nextBoolean;
		                    break;
		                default:
		                    throw new IllegalArgumentException("Invalid operator: " + operator);
		            }
		        }
				if(result == true) {
					tuplesToBeSelected.add(tuple);
				}
		    }
			}
		Iterator<TupleVector<String>> it = tuplesToBeSelected.iterator();
		return it;
		
	}
	
	
	
	
	public static void clrCSV() {
		try (FileWriter fileWriter = new FileWriter("bin\\metadata.csv",false)) {
            // Truncate the file by opening it in write mode
            // This effectively clears all existing content
            //fileWriter.write("");

            System.out.println("CSV file cleared successfully.");

        } catch (IOException e) {
            e.printStackTrace();
        }
	}


	public static void main( String[] args ){
	
	try{
		
//		clrCSV();
//		String strTableName = "Student";
//		DBApp dbApp = new DBApp( );
//	    Hashtable htblColNameType = new Hashtable( ); 
//	    htblColNameType.put("id", "java.lang.Integer"); 
//	    htblColNameType.put("name", "java.lang.String"); 
//	    htblColNameType.put("gpa", "java.lang.Double"); 
//	    dbApp.createTable( strTableName, "id", htblColNameType);
		
//		String strTableName = "Student";
//		DBApp dbApp = new DBApp( );
//		Hashtable htblColNameValue = new Hashtable( );
//		int c = 1;
//		String [] names = {"Ali" , "Ahmed" ,"Omar"};
//		double [] gpas = {0.7 , 0.9 , 1.5, 2.5 , 3.0};
//		boolean flag = true;
//		for(int i = 0 ; i<3 ; i++) {
//			for(int j = 0; j<200 ; j++) {
//				if(i ==1) {
//					htblColNameValue.put("id", c );
//					htblColNameValue.put("name", new String("Ali"));
//					htblColNameValue.put("gpa", new Double(0.7));
//					dbApp.insertIntoTable( strTableName , htblColNameValue );
//					c++;
//				}
//				else if(i ==0 && j == 199 && flag) {
//					c++;
//					j--;
//					flag = false;
//				}
//				else {
//					Random random = new Random();
//			        int randomNumber = random.nextInt(3);
//			        Random rand2 = new Random();
//			        int randomNumber2 = rand2.nextInt(5);
//					htblColNameValue.clear( );
//					htblColNameValue.put("id", c );
//					htblColNameValue.put("name", new String(names[randomNumber]));
//					htblColNameValue.put("gpa", new Double(gpas[randomNumber2]));
//					dbApp.insertIntoTable( strTableName , htblColNameValue );
//					c++;
//				}
//			}
//		}

//	    Page p = Page.loadPage("Student0");
//	    System.out.print(p);
		
//		Table t= Table.loadTable("Student");
//		System.out.println(t.minMax);
//		System.out.print(t.getPages().get(0));
		
//		DBApp dbApp = new DBApp( );
//		dbApp.createIndex( "Student", "id", "idIndex" );
		
//		DBApp dbApp = new DBApp( );
//		dbApp.createIndex( "Student", "gpa", "gpaIndex" );
		
//		DBApp dbApp = new DBApp( );
//		dbApp.createIndex( "Student", "name", "nameIndex" );
		
//		Index in = Index.loadIndex("nameIndex");
//		BTree bpt = in.tree;
////		
//		System.out.println(bpt.search("Ali"));
//		bpt.print();
//		System.out.println(bpt.findGreater(202).size());
//		System.out.println(bpt.findSmaller(202).size());
//		System.out.println(bpt.findNotEqual(202));
		
		
//		System.out.println(bpt.search(1.5).size());
//		System.out.println(bpt.search(2.5).size());
//		System.out.println(bpt.search(3.0).size());
//		v = bpt.findGreater(0.9);
		
//		int res = 0;
//		for(int i = 0; i<v.size();i++) {
//			res += v.get(i).size();
//		}
//		System.out.println(res);
//		bpt.print();
//		System.out.println(bpt.search(200));
		
//		updateIndexCSV( "Student", "gpa" ,  "gpaIndex");
//		updateIndexCSV( "Student", "id" ,  "idIndex");
//		updateIndexCSV( "Student", "name" ,  "nameIndex");
		
		
//		String strTableName = "Student";
//		DBApp dbApp = new DBApp( );
//		Hashtable htblColNameValue = new Hashtable( );
//		htblColNameValue.put("name", new String("Mostafa"));
//		htblColNameValue.put("gpa", new Double( 3.1));
//	    dbApp.updateTable( strTableName, "195" , htblColNameValue);
		
//		String strTableName = "Student";
//		DBApp dbApp = new DBApp( );
//		Hashtable htblColNameValue = new Hashtable( );
////		htblColNameValue.put("id", new Integer(198));
//		htblColNameValue.put("name", new String("Ali"));
////		htblColNameValue.put("gpa", new Double(3.0));
//	    dbApp.deleteFromTable( strTableName, htblColNameValue);
		
//	    Page p = Page.loadPage("Student0");
//	    System.out.print(p);
	    
//		Table t= Table.loadTable("Student");
//		System.out.println(t.pageNames);
//	    Page p = Page.loadPage(t.getPages().get(1));
//	    System.out.print(p);
		
//		for(int i = 201 ; i<397 ; i++) {
//			String strTableName = "Student";
//			DBApp dbApp = new DBApp( );
//			Hashtable htblColNameValue = new Hashtable( );
//			htblColNameValue.put("id", new Integer(i));
//			htblColNameValue.put("name", new String("Ali"));
//			htblColNameValue.put("gpa", new Double(0.7));
//		    dbApp.deleteFromTable( strTableName, htblColNameValue);
//		}
		
		
//		Page p = Page.loadPage("Student10");
//		TupleVector t = p.getTuples().get(0);
//		System.out.print(t);
		
		
//		String strTableName = "Student";
//		DBApp dbApp = new DBApp( );
//		Hashtable htblColNameValue = new Hashtable( );
//		htblColNameValue.clear( );
//		htblColNameValue.put("id", new Integer(603));
//		htblColNameValue.put("name", new String("Ahmed"));
//		htblColNameValue.put("gpa", new Double( 0.95 ));
//		dbApp.insertIntoTable( strTableName , htblColNameValue );
			
			

//
//			htblColNameValue.clear( );
//			htblColNameValue.put("id", new Integer( 5674567 ));
//			htblColNameValue.put("name", new String("Dalia Noor" ) );
//			htblColNameValue.put("gpa", new Double( 1.25 ) );
//			dbApp.insertIntoTable( strTableName , htblColNameValue );
//
//			htblColNameValue.clear( );
//			htblColNameValue.put("id", new Integer( 23498 ));
//			htblColNameValue.put("name", new String("John Noor" ) );
//			htblColNameValue.put("gpa", new Double( 1.5 ) );
//			dbApp.insertIntoTable( strTableName , htblColNameValue );
//
//			htblColNameValue.clear( );
//			htblColNameValue.put("id", new Integer( 58452 ));
//			htblColNameValue.put("name", new String("Zaky Noor" ) );
//			htblColNameValue.put("gpa", new Double( 0.88 ) );
//			dbApp.insertIntoTable( strTableName , htblColNameValue );
			

//
//
//			SQLTerm[] arrSQLTerms;
//			arrSQLTerms = new SQLTerm[2];
//			arrSQLTerms[0] = new SQLTerm();
//			arrSQLTerms[0]._strTableName =  "Student";
//			arrSQLTerms[0]._strColumnName=  "name";
//			arrSQLTerms[0]._strOperator  =  "=";
//			arrSQLTerms[0]._objValue     =  "Ali";
//
//			arrSQLTerms[1] = new SQLTerm();
//			arrSQLTerms[1]._strTableName =  "Student";
//			arrSQLTerms[1]._strColumnName=  "gpa";
//			arrSQLTerms[1]._strOperator  =  "=";
//			arrSQLTerms[1]._objValue     =  new Double( 0.9 );
//			
////			arrSQLTerms[2] = new SQLTerm();
////			arrSQLTerms[2]._strTableName =  "Student";
////			arrSQLTerms[2]._strColumnName=  "gpa";
////			arrSQLTerms[2]._strOperator  =  "<";
////			arrSQLTerms[2]._objValue     =  new Double( 3.0 );
//
//			String[]strarrOperators = new String[1];
//			strarrOperators[0] = "AND";
////			strarrOperators[1] = "XOR";
//			
//			DBApp dbApp = new DBApp( );
//			dbApp.selectFromTable(arrSQLTerms , strarrOperators);
//		
////          select * from Student where name = "John Noor" or gpa = 1.5;
//			Iterator resultSet = dbApp.selectFromTable(arrSQLTerms , strarrOperators);
//	    
//		int c = 0;
//	    while (resultSet.hasNext()) {
//            System.out.println(resultSet.next());
//            c++;
//        }
//	    System.out.println(c);
		}
		catch(Exception exp){
			exp.printStackTrace( );
		}

}
}