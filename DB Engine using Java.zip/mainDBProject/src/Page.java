
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import java.nio.file.*;
import java.util.Properties;


public class Page implements Serializable{
	private Vector<TupleVector<String>>  tuples;
	String name;
	public String getName() {
		return name;
	}

	private int maxSize;
	//static int currSize = 0;

	public Page(String name) {
		super();
		Vector<TupleVector<String>> tuples1 = new Vector<TupleVector<String>>();
		this.maxSize = loadMaxSize();
		this.name = name;
		this.tuples = tuples1;
	}
	
	
	
	public int getMaxSize() {
		return maxSize;
	}



	public static TupleVector addToPage(Hashtable<String,Object> row) {
		Enumeration<String> s = row.keys();
		TupleVector<String> newTuple =  new TupleVector<String>() ;
		while(s.hasMoreElements()) {
			String colName = s.nextElement();
			String dataType = row.get(colName) +"";
		}
		return newTuple;
	}
	
	public static TupleVector addToPage(String key) {
//		Enumeration<String> s = row.keys();
		TupleVector<String> newTuple =  new TupleVector<String>() ;
		newTuple.add(key);
//		while(s.hasMoreElements()) {
//			String colName = s.nextElement();
//			String dataType = row.get(colName) +"";
//		}
		return newTuple;
	}
	
	public static int loadMaxSize() {
		Properties props = new Properties();
		String configFile = "src//resources/DBApp.config";
		int n = 0;
		try (FileInputStream fileInputStream = new FileInputStream(configFile)) {
            props.load(fileInputStream);
            String N = props.getProperty("MaximumRowsCountinPage"); 
            n = Integer.parseInt(N);
		}catch (IOException e) {
            e.printStackTrace();
        }
		return n;
	}
	
	public  void savePage() throws IOException, DBAppException{
		try {
	         FileOutputStream fileOut = new FileOutputStream("bin\\resources\\Pages\\" + this.name + ".class");
	         ObjectOutputStream out = new ObjectOutputStream(fileOut);
	         out.writeObject(this);
	         out.close();
	         fileOut.close();
	      } catch (IOException i) {
	         i.printStackTrace();
	      }
	}
	
	public static Page loadPage(String pageName) throws IOException, DBAppException{
		try {
	         FileInputStream fileIn = new FileInputStream("bin\\resources\\Pages\\" + pageName + ".class");
	         ObjectInputStream in = new ObjectInputStream(fileIn);
	         Page p = (Page) in.readObject();
	         in.close();
	         fileIn.close();
	         return p;
	      } catch (IOException i) {
	         throw new IOException();      
	      } catch (ClassNotFoundException c) {
	         System.out.println("Employee class not found");
	         c.printStackTrace();
	      }
		return null;
	}
	
	public String toString(){
		String result = "";
		for (TupleVector<String> element : tuples) {
			result = result + element.toString()+ "\n------------\n";
        }
		return result;
	}
	

	
	
	public void deleteEmptyPage() {
		if(tuples.size() > 0) {
			return;
		}
		String filePath = this.name + ".ser";

        try {
            Files.delete(Paths.get(filePath));
        } catch (IOException e) {
            e.printStackTrace();
        }
	}

	public Vector<TupleVector<String>> getTuples() {
		return tuples;
	}

	public void setTuples(Vector<TupleVector<String>> tuples) {
		this.tuples = tuples;
	}
	
	

}

