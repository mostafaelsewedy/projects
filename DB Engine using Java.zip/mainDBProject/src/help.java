

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

public class help {
	

	
	public static void main(String[] args) {
		
//		for (int i = 0; i < 3; i++) {
//		    for (int j = 0; j < 3; j++) {
//		        System.out.println(i + ", " + j);
//		        if (j == 1) {
//		            break;
//		        }
//		    }
//		}
		
		
		
		
		
		
		

}
}


